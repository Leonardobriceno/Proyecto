<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Validacion_login</title>
</head>
<body>
<?php
class Recu_pass
{
            public function recuperar($tdoc, $id_usu)

    {
            session_start();
            require_once 'conexion.php';
            $db = database::conectar();

            $sql2="SELECT * FROM usuario where id_us='$id_usu' and fk_pk_tdoc='$tdoc'";
            $result2 = db->query($sql2);    

            while ($row1=$result2->fetch(PDO::FETCH_ASSOC))
            {
                $id_user=stripslashes($row1["id_usu"]);
            }
                if (@$id_user === null)
            {
                    print "<script>alert(\"Usuario no encontrado\"); window.location='index_resetp.html';</script>";

                }
                if  (@id_user !=null)
                {
                    $sql1="UPDATE usuario SET Password = 'temp123' where fk_pk_tdoc = '$tdoc' and id_us = '$id_usu'";
                    $db->query($sql1);
                    print "<script>alert(\"Contraseña temporal: temp123\"); window.location='index_resetp.html';</script>";


                }
        }
    }
$Nuevo=new Recu_pass();
$Nuevo->recuperar($_POST["tdoc"],$_POST["id_usu"]);

    
    
    ?>
    
</body>
</html>