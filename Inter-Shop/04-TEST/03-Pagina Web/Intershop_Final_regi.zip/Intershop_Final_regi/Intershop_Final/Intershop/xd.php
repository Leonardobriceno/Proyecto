<?php
$conexion=mysqli_connect("localhost","root","","db_int");


$basededatos="db_int";
$Nombres1 = $_POST['Nombres'];
$Correo1 = $_POST['Correo'];
$Número1 = $_POST['Número'];
$sql="INSERT INTO registro (Nombres,Correo,Número) VALUES ('$Nombres1', '$Correo1', '$Número1')";

$bd = mysqli_select_db($conexion, $basededatos) or die ('Error conexion al conectarse a la base de datos');


echo "<p style= 'color:green;'>MODIFICACION REALIZADA CON EXITO</p>";
//header('refresh:1; url=index.php');
//header('location: index.php');
echo '<script> alert("REGISTRO SIMULTANEO HECHO"); window.history.go(-1);</script>';
//header('location: index.php');


//echo "<center><img src=\"bien.gif\" alt=\"error\"></center>"; 
		//echo "<script> setTimeout(function(){ window.open('index.php','_self');  }, 2700); </script>";


 $ejecutar= mysqli_query($conexion, $sql);

?>