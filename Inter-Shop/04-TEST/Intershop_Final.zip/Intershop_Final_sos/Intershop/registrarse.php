<?php 
require_once 'conexion.php';




$message = '';



 if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $sql = "INSERT INTO usuario (email, password) VALUES (:email, :password)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password);

 if ($stmt->execute()) {
 	$message = 'Succesfully created new user';
 } else {
    $message = 'Sorry there must have been an issue creating  your password';


 }
}


 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/regis.css">
    <link rel="stylesheet" type="text/css" href="css/style_regi.css">


 
            <a href="#" id="logo" target="_blank">Intershop</a>
            <label for="toggle-1" class="toggle-menu">
            <ul>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            </label>
            <input type="checkbox" id="toggle-1">
            <nav>
              <ul>
                <li><a href="index.html"><i class="fa fa-home"></i>Inicio</a></li>
                <li><a href="#portfolio"><i class="fa fa-thumb-tack"></i>Mas de nosotros</a></li>
                <li><a href="#contact"><i class="fa fa-phone"></i>Contactenos</a></li>
                <li><a href="login.html"><i class="fa fa-user"></i>Login</a></li>
                <li><a href="registrarse.php"><i class="fa fa-user"></i>Registrarse</a></li>
                

<form action="registrarse.php" method="POST">
<div class="loginBox">
<h2>Sign Up Here</h2>
 	<input  type="email" type="text" placeholder="Enter your mail in this place ">
 	<input type="password" name="password" placeholder="Enter your password in this place ">
 	<input type="password" name="confirm_password" placeholder="Enter your confirm_password in this place ">
 	<input type="submit" name="Send">
 </form>
</body>
</html>


              </ul>
            </nav>
          </header>
</head>
<body>
		
