<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

</head>
<body>
<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="login.css">
    <title>Cliente</title>
</head>
<body>
    <h1>Bienvenido Cliente</h1>
 <?php
 class Login 
 {
     public function Login_user($user, $pass)
     {
         session_start();
         require_once 'conexion.php';

         $db = database::conectar();

         $cont=0;

         $sql2="SELECT * from usuario where username='$user' and Password='$pass'";
         $result2= $db->query($sql2);

         while ($row2=$result2->fetch(PDO::FETCH_ASSOC))
         {
             $uusername=stripslashes($row2["username"]);
             $ppasword=stripslashes($row2["Password"]);
             $ffoto=stripslashes($row2["foto_usu"]);

        $cont=$cont+1;
         }
         if ($cont==0)
         {
             print "<script>alert(\"Usuario y/o Password Incorrectas.\"); window.location='index.html';</script>";
         }
         if ($cont!=0)
         {
            $_SESSION['username']=$uusername;
            $_SESSION['foto_usu']=$ffoto;

            $sql1="SELECT fk_rol from usuario where username='$uusername'";
            $result1 = $db->query($sql1);

            while ($row1=$result1->fetch(PDO::FETCH_ASSOC))
            {
                $role=stripslashes($row1["fk_rol"]);
            }
            if (@$role === null)
            {
                print "<script>alert(\"El usuario no tiene asigando rol\"); window.location='index_admin.html';</script>";
            }
            if (@$role === 'Administrador')
            {
                $_SESSION['activate']=1;
                header ('Location: index_admin.html');
            } 
            elseif (@$role === 'Cliente')
            {
                $_SESSION['activate']=1;
                header ('Location: index_client.html');    
            }

            elseif (@$role === 'Temporal')
            {
                print "<script>alert(\"Señor usuario su rol es temporal Porfavor comunicarse con su Administrador\"); window.location='index.html';</script>";

            }
            
         }
     }

 }
    $Nuevo=new Login();
    $Nuevo->Login_user($_POST["user"], $_POST["pass"]);
 
 ?>
</body>
</html>