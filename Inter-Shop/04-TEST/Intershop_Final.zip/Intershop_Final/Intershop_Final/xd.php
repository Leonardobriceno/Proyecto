<?php
$conexion=mysqli_connect("localhost","root","","db_int");


$basededatos="db_int";
$Pass1 = $_POST['Password'];
$Nombres1 = $_POST['nomb_us'];
$Apellidos1 = $_POST['ape_us'];
$estados1 = $_POST['estado_usu'];
$resert_pass1 = $_POST['Resert_Pass'];
$fk_pk_t1 = $_POST['fk_pk_tdoc'];
$fk_rol1 = $_POST['fk_rol'];
$fk_pre_seg = $_POST['fk_pregunta_seg'];

$sql="INSERT INTO usuario (id_us,username,Password,nomb_us,ape_us,estado_usu,Resert_Pass,fk_pk_tdoc,fk_rol,fk_pregunta_seg) 
VALUES ('$Nombres1', '$Apellidos1', '$estados1','$Pass1','$resert_pass1','$fk_pk_t1','$fk_rol1','$fk_pre_seg')";

$bd = mysqli_select_db($conexion, $basededatos) or die ('Error conexion al conectarse a la base de datos');


echo "<p style= 'color:green;'>MODIFICACION REALIZADA CON EXITO</p>";
//header('refresh:1; url=index.php');
//header('location: index.php');
echo '<script> alert("¡Registro con Exito!"); window.history.go(-1);</script>';
//header('location: index.php');


//echo "<center><img src=\"bien.gif\" alt=\"error\"></center>"; 
		//echo "<script> setTimeout(function(){ window.open('index.php','_self');  }, 2700); </script>";


 $ejecutar= mysqli_query($conexion, $sql);

?>