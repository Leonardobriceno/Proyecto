<?php

class database{
    private static $dbhost = "localhost";
    private static $dbName = "db_int";
    private static $dbUsername = "root";
    private static $dbUserpassword = "";

    public static function conectar(){

        try {
            $pdo = new PDO("mysql:host=".self::$dbhost. ";dbname=".self::$dbName,self::$dbUsername,self::$dbUserpassword);
            $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
}


?>