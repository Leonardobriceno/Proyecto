<!DOCTYPE html>
<html>
    <head>
        <title>Intershop</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <header>
            <section>
            <a href="#" id="logo"</a>
            <label for="toggle-1" class="toggle-menu">
            <ul>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            </label>
            <input type="checkbox" id="toggle-1">
            <nav>
              <ul>
              <img src="img/sapo.png"  width="280" height="60" >
                <li><a href="#logo"><i class="fa fa-home"></i>Inicio</a></li>
                <li><a href="#portfolio"><i class="fa fa-thumb-tack"></i>Mas de nosotros</a></li>
                <li><a href="#contact"><i class="fa fa-phone"></i>Contactenos</a></li>
                <li><a href="login.php"><i class="fa fa-user"></i>Login</a></li>
                <li><a href="registrarse.php"><i class="fa fa-user"></i>REGISTRO</a></li>
              </ul>
            </nav>
          </header>
          </section>
         <section class="projects">
             <div class="container">
                 <H2 style="color:#FFFFFF" class="subtutle">Catalogo</H2>
                 <div class="projects__grid">
                     <article class="projects__item">
                         <img src="img/imagen3.jpg" class="projects__img" alt="">
                         <div class="projects__hover">
                           <div class="projects__hover">
                               <a href="contenido.html" class="a">Jeans</a>
                             <i class="far fa-file-alt projects__icon"></i>
                         </div>
                     </article>

                     <article class="projects__item">
                       <img src="img/imagen1.jpg" class="projects__img" alt="">
                       <div class="projects__hover">
                           <a href="contenido.html" class="a" >Camisas</a>
                           <i class="far fa-file-alt projects__icon"></i>
                       </div>
                   </article>

                   <article class="projects__item">
                       <img src="img/imagen4.jpg" class="projects__img" alt="">
                       <div class="projects__hover">
                           <a href="contenido.html" class="a" >Sacos</a>
                           <i class="far fa-file-alt projects__icon"></i>
                       </div>
                   </article>

                   <article class="projects__item">
                       <img src="img/imagen5.jpg" class="projects__img" alt="">
                       <div class="projects__hover">
                           <a href="contenido.html" class="a" >Accesorios</a>
                           <i class="far fa-file-alt projects__icon"></i>
                       </div>
                   </article>
                  
                 </div>
             </div>
         </section>
       
        
    </body>
        <header>
          <section>
            <a href=""></a>

          </section>
        </header>

        <script src="https://kit.fontawesome.com/463006dcd0.js"
        crossorigin="anonymous"></script>   
         

    </body>
</html>