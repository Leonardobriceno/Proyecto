<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/regis.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/style_regi.css">


 
            <a href="#" id="logo" target="_blank">Intershop</a>
            <label for="toggle-1" class="toggle-menu">
            <ul>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            </label>
            <input type="checkbox" id="toggle-1">
            <nav>
              <ul>
                <li><a href="index.php"><i class="fa fa-home"></i>Inicio</a></li>
                <li><a href="#portfolio"><i class="fa fa-thumb-tack"></i>Mas de nosotros</a></li>
                <li><a href="#contact"><i class="fa fa-phone"></i>Contactenos</a></li>
                <li><a href="login.php"><i class="fa fa-user"></i>Login</a></li>
                <li><a href="registrarse.php"><i class="fa fa-user"></i>Registrarse</a></li>
                

<form action="contacto.php" method="POST">
<div class="loginBox">
<article id="REGISTRO">
								<h5  style="color:#FFFFFF" class="major">Sign up Here</h5>
								<form class="inputs-container" method="POST"  action="#"></form>
								
                            <form method="POST" action="xd.php">

                               <div class="form-group">
                               <input type="text" class="form-control form-control-lg" name="Nombres" placeholder="Nombres">
                               </div>
                              <div class="form-group">
                                <input type="text" class="form-control form-control-lg" name="Apellidos" placeholder="Apellido">
                               </div>
                               <div class="form-group">
                                <input type="text" class="form-control form-control-lg" name="estados" placeholder="estado">
                          
                               <div class="form-group">
                                <input type="text" class="form-control form-control-lg" name="Pass" placeholder="Contraseña">
                               </div>
                               <div class="form-group">
                                <input type="number" class="form-control form-control-lg" name="fk_pk_t1" placeholder="Tipo Documento">
                               </div>
                              <div class="form-group">
                                <input type="text" class="form-control form-control-lg" name="fk_rol" placeholder="Rol de Usuario">
                              </div><br>
                              <div class="form-group">
                               

                                <input type="submit" value="ENVIAR">
				            </form>
			            </article>
</body>
</html>



              </ul>
            </nav>
          </header>
</head>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
<body>
		
