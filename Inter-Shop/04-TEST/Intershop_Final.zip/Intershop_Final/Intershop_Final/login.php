<!DOCTYPE html>
<html>
    <head>
        <title>Intershop</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/login.css">
    </head>
    <body>
        <header>
            <section>
            <a href="index.php" id="logo" target="_blank">Intershop</a>
            <label for="toggle-1" class="toggle-menu">
            <ul>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            </label>
            <input type="checkbox" id="toggle-1">
            <nav>
              <ul>
                <li><a href="index.php"><i class="fa fa-home"></i>Inicio</a></li>
                <li><a href="#portfolio"><i class="fa fa-thumb-tack"></i>Mas de nosotros</a></li>
                <li><a href="#contact"><i class="fa fa-phone"></i>Contactenos</a></li>
                <li><a href="login.php"><i class="fa fa-user"></i>Login</a></li>
                <li><a href="registrarse.php"><i class="fa fa-user"></i>Registrarse</a></li>
              </ul>
            </nav>
          </header>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/login.css">
</head>
<img src="img/black.png" align="left" width="480" height="350" />
<div class="loginBox">

<div class="container">

</div>
<body>
 

  
  <br>
  <h2>Login Here</h2>
  <form class="inputs-container" method="POST" action="validacion.php">
    <input type="text" name="user" placeholder="Ingrese su Correo electronico" required>
    <input type="password" name="pass" placeholder="Ingrese su Password" required>
    <button class="btn">Ingresar</button>
    <li><a href="frm_recu_pass.php">Recuperar contrasena</a></li>
  </form>
</div>
</body>
</html> 
