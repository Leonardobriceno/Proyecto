<!DOCTYPE html>
<html>
<head>
<meta charset=UTF-8/>
<title> Validacion_login</title>
</head>
<body>
<?php
class Recu_pass
{
   public function recuperar($tdoc, $id_usu)
   {
       session_star();
       require_once '../Base_de_Datos/database.php';
       $db = database::conectar();

       $sql2="SELECT * FROM usuario WHERE id_us='$id_usu' AND fk_pk_tdoc='$tdoc'";
       $result2 = $db->query($sql2);

       while ($row1=$result2-> fetch(PDO::FETCH_ASSOC))
       {
           $id_user=stripslashes($row1["id_us"]);
       }
       if (@$id_user === null)
       {
           print "<script>alert(\"Usuario no encontrado\");Window.location'../frm_recu_pass.php';<\script>";
       }
       if (@$id_user != null)
       {
           $sql1="UPDATE usuario SET Password = 'temp123' WHERE fk_pk_tdoc = '$tdoc' AND id_us = '$id_usu'";
           $db->query($sql1);
           print "<script>alert(\"Password Temporal: temp123\");Window.location'../frm_recu_pass.php';<\script>";
       }

   }// finalizando el metodo
}//cerrando la clase

     $Nuevo=new Recu_pass();
     $Nuevo->recuperar($_POST["tdoc"],$_POST["id_usu"]);
     ?>
     </body>
     </html>