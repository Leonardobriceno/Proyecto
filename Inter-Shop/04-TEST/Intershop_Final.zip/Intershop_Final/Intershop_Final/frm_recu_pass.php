<?php
?>
<div class="container">
<link rel="stylesheet" href="css/recu.css">
<form method="post" action="validacion_login.php">
<h1>Recuperacion de Contraseña Intershop</h1>

 <label>Tipo Documento</label>
   <select name="tdoc" class="form-control">
    <?php
       foreach ($db->query('SELECT t_doc,des_tdoc, estado_tdoc FROM tipo_documento where
       estado_tdoc = 1')as $row)
       {
           echo '<option value="'. $row['t_doc'] .'">'. $row['desc_tdoc'] . '</option>';
       }
    ?>
    </select><p>


    <p><label>N° Documento</label>
    <input type="text" placeholder="N° identificacion" name="id_usu" class="from-control" required>

    <p><input type="submit" class="btn btn-info" value="Validar">
    <a href="login.php" class="btn btn-primary">Regresar</a>

    </form>
    </div>