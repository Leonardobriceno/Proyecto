<?php
 
 if(!isset$_SESSION['id'])){
 header(location:"index.php")
 }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Administrador</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/style_admin.css">
    </head>
    <body>
        <header>
            <section>
            <a href="#" id="logo" target="_blank">Administrador</a>
            <label for="toggle-1" class="toggle-menu">
            <ul>
              <li></li>
              <li></li>
              <li></li>
            </ul>
            </label>
            <input type="checkbox" id="toggle-1">
            <nav>
              <ul>
                <li><a href="catalogo_admin.html"><i class="fa fa-newspaper-o"></i>Catalogo</a></li>
                <li><a href="#contact"><i class="fas fa-shopping-cart"></i>Carrito</a></li>
                <li><a href="login.php"><i class="fa fa-user"></i>Login</a></li>
                <li><a href="index.php"><i class="far fa-door-closed"></i>Salir</a></li>
              </ul>
            </nav>
          </header>
          </section>

          <h2>Bienvenido Administrador</h2>
    </body>
</html>