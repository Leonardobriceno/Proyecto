Create database db_int;
use db_int;
CREATE TABLE rol(
    rol_usu varchar(20) not null ,
    estado_rol boolean not null ,
    primary key (rol_usu)
);

CREATE TABLE usuario(
    id_us varchar(25) not null ,
    username varchar(20) not null ,
    Password varchar(20) not null ,
    nomb_us varchar(45)not null  ,
    ape_us varchar(45)not null  ,
    dlr_us varchar(45) not null ,
    td_us bigint not null ,
    foto_usu varchar(45) not null ,
    estado_usu boolean not null ,
    Resert_Pass varchar(100)not null ,
    fk_pk_tdoc varchar(10) not null,
    fk_rol varchar(20)not null,
    fk_pregunta_seg int not null,
    primary key (id_us,fk_pk_tdoc)
);

CREATE TABLE vendedor (
    id integer NOT NULL,
    id_user varchar(25) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE tipo_pago (
    id integer NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE pedido (
    id integer NOT NULL,
    fecha date NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE tipo_documento (
    t_doc varchar(10) not null ,
    desc_tdoc varchar(45)not null  ,
    estado_tdoc BOOLEAN not null  ,
    primary key (t_doc)

);

CREATE TABLE factura (
    id integer NOT NULL,
    numero_factura varchar(500) NOT NULL UNIQUE,
    fecha date NOT NULL,
    total varchar(500),
    id_vendedor integer NOT NULL,
    id_tipo_pago integer NOT NULL,
    id_pedido integer NOT NULL,
    id_cliente integer,
    PRIMARY KEY (id)
);

CREATE TABLE almacen (
    id integer NOT NULL,
    id_tipo_documento varchar(10) NOT NULL UNIQUE,
    numero_documento varchar(500) NOT NULL UNIQUE,
    nombre varchar(1000) NOT NULL,
    direccion varchar(1000) NOT NULL,
    telefono varchar(1000) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE categoria (
    id integer NOT NULL,
    nombre varchar(500) NOT NULL,
    estado varchar(80) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE referencia (
    id integer NOT NULL,
    nombre varchar(500) NOT NULL,
    estado varchar(80) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE producto (
    id integer NOT NULL,
    serial_pro varchar(500) NOT NULL UNIQUE,
    nombre varchar(500) NOT NULL,
    stock varchar(100) NOT NULL,
    imagen varchar(100) NOT NULL,
    precio varchar(500) NOT NULL,
    id_categoria integer,
    id_referencia integer,
    PRIMARY KEY (id)
);

CREATE TABLE almacen_producto (
    id_almacen integer NOT NULL,
    id_producto integer NOT NULL,
    stock varchar(500),
    PRIMARY KEY (id_almacen, id_producto)
);

CREATE TABLE pedido_producto (
    id integer NOT NULL,
    Cantidad varchar(500) NOT NULL,
    precio_venta varchar(500) NOT NULL,
    id_pedido integer NOT NULL UNIQUE,
    id_producto integer NOT NULL UNIQUE,
    PRIMARY KEY (id)
);





Alter table vendedor
add constraint fk_user2
foreign key (id_user)
references usuario (id_us);

Alter table factura
add constraint fk_vendedor
foreign key  (id_vendedor)
references vendedor (id);

Alter table factura
add constraint fk_tipo_pago
foreign key (id_tipo_pago)
references tipo_pago (id);

Alter table factura
add constraint fk_pedido
foreign key (id_pedido)
references pedido (id);

Alter table almacen
add constraint fk_tipo_documento
foreign key (id_tipo_documento)
references tipo_documento (t_doc);

Alter table producto
add constraint fk_categoria
foreign key (id_categoria)
references categoria (id);

alter table producto
add constraint fk_referencia
foreign key (id_referencia)
references referencia (id);

Alter table almacen_producto
add constraint fk_almacen
foreign key (id_almacen)
references almacen(id);

Alter table almacen_producto
add constraint fk_producto
foreign key (id_producto)
references producto (id);

Alter table pedido_producto
add constraint fk_pedido2
foreign key (id_pedido)
references pedido (id);

Alter table pedido_producto
add constraint fk_producto2
foreign key (id_producto)
references producto (id);

Alter table usuario
add constraint fk_pktdoc
foreign key (fk_pk_tdoc)
references tipo_documento(t_doc);

Alter table usuario
add constraint fk_rol
foreign key (fk_rol)
references rol (rol_usu);

/*Insert into usuario 
values ('1','Andryu','123',"Andewl","Silva",'cll71d#77M49sur',3118408715,"img.png",1,"MAI",'CC','Administrador',1),
('2','andres','123a','andre','torres','cll78d#65A36sur',3214587856,"img.png",1,"ANDT",'CC','temporal',1),
('3','andrea','123b','andrea','trujillo','cll9d#17C25sur',3163248569,"img.png",1,"antru",'CC','cliente',1);*/

/*Insert into tipo_documento
values 
('CC','Cedula de ciudadania','1'),
('CE','Cedula de Extranjeria','2'),
('TI','Tarjeta de identidad','3');*/

/*Insert into rol
values ('Administrador','1'),
('Cliente','1'),
('Temporal','1');
*/

/*Primero crear Tipo de documento luego rol y despues usuario*/